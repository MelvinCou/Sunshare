<html>
 <head>

   <link charset="UTF-8" href="../CSS/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
   <script src="../lib_jQuery/js/bootstrap.bundle.js"></script>



   <link charset="UTF-8" href="../CSS/MesStyles.css" rel="stylesheet" type="text/css" />
   <link charset="UTF-8" href="../CSS/Vibur.css" rel="stylesheet" type="text/css" />
   <meta http-equiv="content-type" content="text/html;charset=UTF-8">

 <title>SunShare Supervisor | Graph </title>


 </head>
 <body>


   <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
     <div class="container-fluid">
       <a class="navbar-brand" href="#"><img src="../Images/SnSr_logo.png" alt="SunShare Logo" style="width:40px;" class="rounded-pill">
           SunShare Supervisor
       </a>
       <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
         <span class="navbar-toggler-icon"></span>
       </button>
       <div class="collapse navbar-collapse" id="collapsibleNavbar">
         <ul class="navbar-nav">
           <li class="nav-item">
             <a class="nav-link" href="page_accueil.php">Accueil</a>
           </li>


                <li class="nav-item">
                  <a class="nav-link" href="#" >Historique</a>
                </li>


         </ul>
       </div>
     </div>
   </nav>


   <div class="container-fluid">
     <div class="container">

      <div class="row ">
           <article class="col-xs-12 col-md-2 col-lg-4">
           </article>

           <div class="container-fluid ">
           <article class="col-md-">

           </article>
           </div>
      </div>



  </div>

   </BR>

<?php


   $ServeurBdD = "127.0.0.1" ;
   $PortBdD = "3306";
   $User = "admin" ;
   $Password = "admin" ;
   $BdD = "SunshareBDD" ;

   // Connexion au serveur de la base de données
   $bConnect = mysqli_connect(
           $ServeurBdD.":".$PortBdD,
           $User,
           $Password,
           $BdD) ;
   if(!$bConnect)
   {
     Echo '<BR/><BR/><B>Connexion au serveur de Base de Données impossible</B><BR/>' ;
     exit() ;
   }



    $Requete = "SELECT date, energie_soutiree, energie_injectee, energie_produite FROM Energies LIMIT 7 " ;
	//echo $Requete ;

    $Resultat = mysqli_query($bConnect, $Requete);

    echo mysqli_error($bConnect);




  if (mysqli_num_rows($Resultat) <> 0)
    {
	  $energie_produite = array();
    $energie_soutiree = array();
    $energie_produite = array();

    $date = array();

		while($row=mysqli_fetch_array($Resultat))
			{
				 // $json[] = $row;

			    $energie_produite[] = $row["energie_produite"];
          $energie_soutiree[] = $row["energie_soutiree"];
          $energie_injectee[] = $row["energie_injectee"];


			    $date [] = $row["date"];
				//echo $row["energie_produite"];
			}

   //echo json_encode($json, JSON_UNESCAPED_UNICODE);

    //echo print_r($energie_produite);
    //echo print_r($date);

    }
    else
    {
		echo "Pas de résultats !" ;
	}


    mysqli_close($bConnect);

   ?>


<form>

  <div class="form-row align-items-center">


   <div class="col-md-3 position-relative">
    <label for="validationTooltip04" class="form-label"> Grahique à afficher</label>
    <select class="form-select" id="validationTooltip04" required>
      <option selected disabled value="">Choisir...</option>

      <option> Evolution : production, injection et consommation journalière </option>
      <option> Evolution : production, injection et consommation hebdomadaire </option>
      <option> Evolution : production, injection et consommation mensuelle </option>
      <option> Evolution : production, injection et consommation annuelle </option>

    </select>
    <div class="invalid-tooltip">
      Please select a valid state.
   </div>



    </div>

    <div class="col-auto my-1">
      <button type="button" class="btn btn-outline-success">Valider</button>
    </div>

  </div>

</form>


<!-- canvas pour le graphique production journalère  -->

   <div class="col">

            <div class="container ; border border-success"  style="width:70%">

               <canvas id="MyChartBar">  </canvas>

           </div>
   </div>



                       <script src="https://cdn.jsdelivr.net/npm/chart.js">  </script>

                         <script>
                          //setup Block

                           //console.log(<?php echo json_encode($energie_produite); ?>);

                          const energie_produite = <?php echo json_encode($energie_produite); ?>;
                          const energie_soutiree = <?php echo json_encode($energie_soutiree); ?>;
                          const energie_injectee = <?php echo json_encode($energie_injectee); ?>;

                          const date = <?php echo json_encode($date); ?>;

                          const data = {
                                  labels: date,
                                  datasets: [
                                    {
                                      label: 'Production journalère cette semaine',
                                      data: energie_produite,
                                      backgroundColor :['rgba(75, 192, 192, 0.2)',],
                                      borderColor: ['rgba(75, 192, 192, 1)',],
                                      borderWidth : 1
                                    },{
                                      //label: 'Production journalère cette semaine',
                                      data: energie_soutiree,
                                      backgroundColor :['rgba(255, 206, 86, 0.2)',],
                                      borderColor: ['rgba(255, 206, 86, 1)',],
                                      borderWidth : 1
                                    },{
                                      //label: 'Production journalère cette semaine',
                                      data: energie_injectee,
                                      backgroundColor :['rgba(54, 162, 235, 0.2)',],
                                      borderColor: ['rgb(54, 162, 235)',],
                                      borderWidth : 1
                                    }]

                       };

                          //Config Block
                          const config = {
                             type: 'bar',
                             data,
                                options: {
                                      scales: {
                                          yAxes: {
                                                  beginAtZero:true
                                          }
                                      }
                                  }
                              };





                          // Render Block
                        const MyChartBar = new Chart(
                         document.getElementById("MyChartBar"),
                         config

                     );

                        </script>



     </div>
</div>


 </body>
</html>
