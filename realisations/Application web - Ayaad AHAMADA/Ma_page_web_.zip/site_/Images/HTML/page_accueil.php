<html>
  <head>

    <link charset="UTF-8" href="../CSS/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <script src="../lib_jQuery/js/bootstrap.bundle.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>



    <link charset="UTF-8" href="../CSS/MesStyles.css" rel="stylesheet" type="text/css" />
    <link charset="UTF-8" href="../CSS/Vibur.css" rel="stylesheet" type="text/css" />
    <meta http-equiv="refresh; content-type" content="10;text/html;charset=UTF-8">

  <title>SunShare Supervisor | Accueil </title>
  </head>
  <body>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="#"><img src="../Images/SnSr_logo.png" alt="SunShare Logo" style="width:40px;" class="rounded-pill">
            SunShare Supervisor
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
		
		
           <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="../HTML/page_accueil.php">Accueil</a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" href="../HTML/page_historique.html" >Historique</a>
                </li>

                <li class="nav-item ">         
                    <a class="nav-link" href="../HTML/page_graph.php">Graphique</a>
                </li>

                <li class="nav-item ">
                    <a class="nav-link" href="https://sunshare.fr/">SunShare</a>
                </li>
		  
        </div>
      </div>
    </nav>


    <div class="container-fluid">
      <div class="container">

        <div class="row ">

			  <article class="col-xs-12 col-md-2 col-lg-4">

        <section>

          <table>
            
          <?php

          $ServeurBdD = "127.0.0.1" ;
          $PortBdD = "3306";
          $User = "admin" ;
          $Password = "admin" ;
          $BdD = "SunshareBDD" ;

          // Connexion au serveur de la base de données
          $bConnect = mysqli_connect(
                  $ServeurBdD.":".$PortBdD,
                  $User,
                  $Password,
                  $BdD) ;
          if(!$bConnect)
          {
            Echo '<BR/><BR/><B>Connexion au serveur de Base de Données impossible</B><BR/>' ;
            exit() ;
          }else
            {

            // instructions et requêtes sur la base de données
            $Requete = "SELECT nom, prenom, num_PDL FROM utilisateurs WHERE id=1;" ;
            
          


            //echo $Requete ;
            $Resultat = mysqli_query($bConnect,$Requete) ;
            


            if ($Resultat) {
              if (mysqli_num_rows($Resultat) > 0) {
               while($row = mysqli_fetch_assoc($Resultat)) {
                 
                      echo "<H3> <B>Bienvenue sur SunShare Supervisor </B> </H3>" ;
                      echo "<tr><td>".$row["nom"]."</td><td>".$row["prenom"]."</td></tr>\n";
                      echo "<tr><td> N°PDL </td><td>".$row["num_PDL"]."</td></tr>\n";
               }
              }
             }
                 mysqli_close($bConnect);
            }

          ?>

          </table>
          </section>


			  </article>

			 <div class="container-fluid ">
				<article class="col-md-">

      </article>
			</div>

        </div>

 </BR> </BR>
    
    
   
 <div id="carouselExampleInterval" class="mx-auto d-block w-50 h-25 carousel slide" data-bs-ride="carousel">
	  <div class="carousel-inner">
		<div class="carousel-item active" data-bs-interval="10000">
		  <img src="../Images/production.jpg" class="d-block w-100" alt="...">
		  </BR> </BR> </BR>
		</div>
		<div class="carousel-item" data-bs-interval="2000">
		  <img src="../Images/autoconso.png" class="d-block w-100" alt="...">
		  </BR> </BR> </BR>
		</div>
		<div class="carousel-item">
		  <img src="../Images/injection.png" class="d-block w-100" alt="...">
		  </BR> </BR></BR> 
		</div>
	  </div>
	  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Previous</span>
	  </button>
	  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Next</span>
	  </button>
</div>
   
   
    </BR></BR> </BR> </BR> </BR> </BR> </BR> </BR> </BR>
    
          <h4 style="text-align : center;" >Vos données enregistrées en temps réel </h4>

   </div>

    </BR>

        <div class="container" >

        </BR></BR>

        
		  <table class="table "  id="table-to-refresh">
			
			  <thead class="table-warning">
				<tr>
				  
				  <th scope="col" style="text-align : center;">Production (kwh)</th>
				  <th scope="col" style="text-align : center;">Consommation (kwh)</th>
				  <th scope="col" style="text-align : center;"> Injection (kwh)</th>
				  
				</tr>
			  </thead>
			  <tbody>
				<tr class = TailTab >
						
			
			   <?php   
				  include ('../PHP/EnergiesWeb.php');          
				?>   
				
				</tr>
			   
			  </tbody>

		   </table>


    </div>



	
	
</BR></BR>
    <script src="../lib_jQuery/jquery-3.6.0.js"></script>
    <script src="../lib_jQuery/bootstrap.min.js"></script>



    <script  type="text/javascript">
      
     setInterval (function(){
      
      $("#table-to-refresh").load ("page_accueil.php #table-to-refresh")
      
      }, 2000);
    
    </script>

  </body>
</html>
