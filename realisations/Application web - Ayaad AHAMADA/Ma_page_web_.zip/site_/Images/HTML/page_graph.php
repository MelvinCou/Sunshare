<html>
 <head>


   <link charset="UTF-8" href="../CSS/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
   <script src="../lib_jQuery/js/bootstrap.bundle.js"></script>



   <link charset="UTF-8" href="../CSS/MesStyles.css" rel="stylesheet" type="text/css" />
   <link charset="UTF-8" href="../CSS/Vibur.css" rel="stylesheet" type="text/css" />
   <meta http-equiv="content-type" content="text/html;charset=UTF-8">
   
<script src="../ChartJS/dist/chart.min.js">  </script>

 <title>SunShare Supervisor | Graph </title>


 </head>
 <body>


   <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
     <div class="container-fluid">
       <a class="navbar-brand" href="#"><img src="../Images/SnSr_logo.png" alt="SunShare Logo" style="width:40px;" class="rounded-pill">
           SunShare Supervisor
       </a>
       <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
         <span class="navbar-toggler-icon"></span>
       </button>
       <div class="collapse navbar-collapse" id="collapsibleNavbar">
         <ul class="navbar-nav">
           <li class="nav-item">
             <a class="nav-link" href="page_accueil.php">Accueil</a>
           </li>


                <li class="nav-item">
                  <a class="nav-link" href="../HTML/page_historique.html" >Historique</a>
                </li>


         </ul>
       </div>
     </div>
   </nav>


   <div class="container-fluid">
     <div class="container">

      <div class="row ">
           <article class="col-xs-12 col-md-2 col-lg-4">
           </article>

           <div class="container-fluid ">
           <article class="col-md-">

           </article>
           </div>
      </div>



  </div>

   </BR>

<?php
   
  $DateD= $_POST['DebutDate'];
  $DateF= $_POST['FinDate'];
  $Select = $_POST['Select'];

   $ServeurBdD = "127.0.0.1" ;
   $PortBdD = "3306";
   $User = "admin" ;
   $Password = "admin" ;
   $BdD = "SunshareBDD" ;

   // Connexion au serveur de la base de données
   $bConnect = mysqli_connect(
           $ServeurBdD.":".$PortBdD,
           $User,
           $Password,
           $BdD) ;
   if(!$bConnect)
   {
     Echo '<BR/><BR/><B>Connexion au serveur de Base de Données impossible</B><BR/>' ;
     exit() ;
   }



   if(isset($_POST['Select'])){
	   
	   
		switch ($Select) {
			
				case 'journaliere':				
					$Requete = "SELECT date, energie_soutiree, energie_injectee, energie_produite FROM Energies WHERE date BETWEEN \"".$DateD."\" AND \"".$DateF."\" LIMIT 7 " ;
					
					break;
					
				case 'hebdomadaire':
					$Requete = "SELECT date, energie_soutiree, energie_injectee, energie_produite FROM Energies WHERE date BETWEEN \"".$DateD."\" AND \"".$DateF."\"  ORDER BY date DESC LIMIT 7 " ;
					//echo  $Requete;
					break;
					
				case 'mensuelle':
					echo 'value3 <br/>';
					break;
					
				case 'annuelle':
					echo 'value4 <br/>';
					break;			
				
				
				default:
					# code...
					break;
				
		}
}
  
    //$Requete = "SELECT date, energie_soutiree, energie_injectee, energie_produite FROM Energies WHERE date BETWEEN \"".$DateD."\" AND \"".$DateF."\" LIMIT 7 " ;
	
    $Resultat = mysqli_query($bConnect, $Requete);

    //echo mysqli_error($bConnect);




  if (mysqli_num_rows($Resultat) <> 0)
    {
	  $energie_produite = array();
	  $energie_soutiree = array();
	  $energie_produite = array();

    $date = array();

		while($row=mysqli_fetch_array($Resultat))
			{
				 // $json[] = $row;
		    //if ()
			    $energie_produite[] = $row["energie_produite"];
				$energie_soutiree[] = $row["energie_soutiree"];
				$energie_injectee[] = $row["energie_injectee"];


			    $date [] = $row["date"];
				//echo $row["energie_produite"];
			}

   //echo json_encode($json, JSON_UNESCAPED_UNICODE);

    //echo print_r($energie_produite);
    //echo print_r($date);

    }
   // else
    //{
		//echo "Pas de résultats !" ;
//	}


    mysqli_close($bConnect);

   ?>


<form  ACTION="../HTML/page_graph.php" METHOD="POST">

	<div class="container">

 
 </br></br>
 
<!-- La saisie de date   -->

  <div class="row justify-content-center">
  	
	<h5 for="party" ; style="text-align:center";>  Définir une période, pour la consultation graphique </h5>
</br></br>
    <div class="col-md-auto">
     		  <table align="center">
				 
                 <tr>
                 <td>
				 
                       <div class="custom-control custom-checkbox mb-3" >

                            <input class="shadow-lg p-2 mb-5 bg-white" type="dateTime" name="DebutDate" placeholder ="yy-mm-dd HH:mm:ss" required>
                            <span class="validity"></span>

                       </div>
                      <input type="hidden" id="timezone" name="timezone">
                </td>
						
                <td>
			
                      <div class="custom-control custom-checkbox mb-3">
                          <input class="shadow-lg p-2 mb-5 bg-white" type="dateTime" name="FinDate" placeholder ="yy-mm-dd HH:mm:ss"  required>
                          <span class="validity"></span>
                      </div>
                      <input type="hidden" id="timezone" name="timezone" >
                </td>


            </table>
		  
    </div>
	
    <div class="col-md-auto">
      <div class="col-11"> <button  type="submit" ; class="btn btn-outline-success mb-5 ">Valider</button> </div>
    </div>
  </div>



	
	 <div class="row justify-content-center">
	 
<!-- La selection de mode bar et ligne  checked -->

	<form  ACTION="../PHP/SwitchBarLine.php" METHOD="POST">
			 <div class="col-md-auto">
			 <label for="validationTooltip04" class="form-label" style = "text-align : center"> Visualisation graphique </label>
			 
				<div class="form-check form-switch">
				  <input class="form-check-input" type="checkbox" value="1" name="bar" role="switch" id="flexSwitchCheckChecked" >
				  <label class="form-check-label" for="flexSwitchCheckChecked">Bar</label>
				</div>
				
				<div class="form-check form-switch">
				  <input class="form-check-input" type="checkbox" value="2" name="line" role="switch" id="flexSwitchCheckDefault">
				  <label class="form-check-label" for="flexSwitchCheckDefault">ligne</label>
				</div>

				
			 </div>
	</form>
	 
 <!-- La selection période   -->
 
		<div class="col-md-auto">
			
				 <div class="col">
						<label for="validationTooltip04" class="form-label" style = "text-align : center"> Période </label>
						</br>
						
						<select name="Select" class="form-select" id="validationTooltip04" required>
						  <option selected disabled value="">Choisir...</option>
						  
						  <option value = "journaliere"> Evolution : production, injection et consommation journalière </option>
						  <option value = "hebdomadaire"> Evolution : production, injection et consommation hebdomadaire </option>
						  <option value = "mensuelle"> Evolution : production, injection et consommation mensuelle </option>
						  <option value = "annuelle"> Evolution : production, injection et consommation annuelle </option>

						</select>
						<div class="invalid-tooltip">
						  Please select a valid state.
					   </div>
			   
				</div>
			  
			
		</div>
	 </div>
</div>	
	</br>
	
	
</form>

<?php

		if ($Select == 'journaliere'){	
			
			echo "<h5 style =\"text-align : center;\" > Energie journalière du  $DateD  au  $DateF  </h5>";

		}else if  ($Select == 'hebdomadaire'){
			
				echo "<h5 style =\"text-align : center;\" > Energie hebdomadaire du $DateD au  $DateF </h5>";
			
		}else if  ($Select == 'mensuelle'){
			
				echo "<h5 style =\"text-align : center;\" > Energie mensuelle du $DateD au  $DateF </h5>";
				
		}else if  ($Select == 'annuelle'){
			
				echo "<h5 style =\"text-align : center;\" > Energie annuelle du $DateD au  $DateF </h5>";
		}
 
 
?>

</br>
<!-- canvas pour le graphique bar  -->

   <div class="col">

            <div class="container ; border border-success"  style="width:70%">

               <canvas id="MyChartBar">  </canvas>

			</div>
   </div>
   
   </br></br>
<!-- canvas pour le graphique line  -->

   <div class="col">

            <div class="container ; border border-dark"  style="width:70%">

               <canvas id="MyChartLine">  </canvas>

			</div>
   </div>

 


</BR>



 <!-- Script pour le graphique Bar -->

            <script>
                          //Bloc setup 
                          //console.log(<?php echo json_encode($energie_produite); ?>);

                          const energie_produite = <?php echo json_encode($energie_produite); ?>;
                          const energie_soutiree = <?php echo json_encode($energie_soutiree); ?>;
                          const energie_injectee = <?php echo json_encode($energie_injectee); ?>;

                          const date = <?php echo json_encode($date); ?>;

                          const data = {
                                  labels: date,
                                  datasets: [
                                    {
                                      label: 'Production (Kwh)',
                                      data: energie_produite,
                                      backgroundColor :['rgba(93, 173, 226, 0.6)',],
                                      borderColor: ['rgba(23, 32, 42, 1)',],
                                      borderWidth : 1
                                    },{
                                      label: 'Consommation (Kwh)',
                                      data: energie_soutiree,
                                      backgroundColor :['rgba(247, 220, 111, 1)',],
                                      borderColor: ['rgba(23, 32, 42, 1)',],
                                      borderWidth : 1
                                    },{
                                      label: 'Injection (Kwh)',
                                      data: energie_injectee,
                                      backgroundColor :['rgba(220, 118, 51, 0.6',],
                                      borderColor: ['rgba(23, 32, 42,1)',],
                                      borderWidth : 1
                                    }]

                       };

                        //Bloc Config bar
                          const config = {
                             
                             type: 'bar',
                             data,
							 
                                options: {
                                      scales: {
                                          yAxes: {
                                                  beginAtZero:true,
												
                                          }
                                      },
									  
									  
                                     
                                  }
                              };



                        // Bloc de rendu  bar
                        const MyChartBar = new Chart(
                         document.getElementById('MyChartBar'),
                         config

                     );
					 

	
					 //Bloc Config line 
					 
                          const ConfigLine = {
                             
                             type: 'line',
                             data,
							 
                                options: {
                                      scales: {
                                          yAxes: {
                                                  beginAtZero:true,
												
                                          }
                                      },
									  
									  
                                     
                                  }
                              };
							  
						// Bloc de rendu  line
						
						const MyChartLine = new Chart(
						  document.getElementById('MyChartLine'),
						  ConfigLine

						);
						
	
            </script>

   <!-- Script pour le graphique ligne -->			
   
		

			
			
			</script>



     </div>
</div>


 </body>
</html>
