<?php

	$user_nom = ' Dupont ';
	$user_Prenom = ' Gérard ';
	$Num_pdl = '14200000000022'; 


?>