<?php
			
	$DateD= $_POST['DebutDate'];
	$DateF= $_POST['FinDate'];
	$Select = $_POST['Select'];

	//inclusion du fichier connexion bdd
	require 'ConnexionBdD.php';

	if(isset($_POST['Select'])){
						   
		switch ($Select){
				//Choix 1 : journalier (pour consulter l'historique journalier)
				case 'journalier':				
						$Requete = "SELECT date, energie_soutiree, energie_injectee, energie_produite FROM Energies_Journaliere WHERE date BETWEEN \"".$DateD."\" AND \"".$DateF."\" ORDER BY date DESC LIMIT 7 " ;		
						break;
				//Choix 2 : hebdomadaire (pour consulter l'historique hebdomadaire)	
				case 'hebdomadaire':
						$Requete = "SELECT date, energie_soutiree, energie_injectee, energie_produite FROM Energies_Hebdomadaire WHERE date BETWEEN \"".$DateD."\" AND \"".$DateF."\" ORDER BY date DESC LIMIT 7 " ;
						break;
				//Choix 3 : mensuel (pour consulter l'historique mensuel)	
				case 'mensuel':
						$Requete = "SELECT energie_soutiree, energie_injectee, energie_produite, date FROM Energies_Mensuelle WHERE date BETWEEN \"".$DateD."\" AND \"".$DateF."\" ORDER BY date DESC LIMIT 7;" ;
						 break;
				//Choix 4 : annuel (pour consulter l'historique annuel)	 
				case 'annuel':
						$Requete = "SELECT energie_soutiree, energie_injectee, energie_produite, date FROM Energies_Annuelle WHERE date BETWEEN \"".$DateD."\" AND \"".$DateF."\" ORDER BY date DESC LIMIT 7;" ;
						break;					
												
				default:
						break;								
		}
	}


	$Resultat = mysqli_query($bConnect, $Requete);

	if (mysqli_num_rows($Resultat) <> 0){
	  
		$energie_produite = array();
		$energie_soutiree = array();
		$energie_produite = array();
		$date = array();

		//mysqli_fetch_array renvoie les données dans un tableau associatif avec un nom de colonne comme clé du tableau résultant.
		//Cela veut dire que nous pouvons accéder au tableau de sortie avec un nom de colonne comme clé d'un tableau.
		while($row=mysqli_fetch_array($Resultat)){
										
				$energie_produite[] = $row["energie_produite"];
				$energie_soutiree[] = $row["energie_soutiree"];
				$energie_injectee[] = $row["energie_injectee"];
				$date [] = $row["date"];
				
		}
	}

	// else{
		//echo "Pas de résultats !" ;
	//}

?>