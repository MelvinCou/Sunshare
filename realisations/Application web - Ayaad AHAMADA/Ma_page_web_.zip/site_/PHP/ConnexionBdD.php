<?PHP 


	$ServeurBdD = "127.0.0.1" ;
	$PortBdD = "3306";
	$User = "admin" ;
	$Password = "admin" ;
	$BdD = "SunshareBDD" ;

	// Connexion au serveur de la base de données
	$bConnect = mysqli_connect(
		  $ServeurBdD.":".$PortBdD,
		  $User,
		  $Password,
		  $BdD) ;
	if(!$bConnect){
		  
		Echo '<BR/><BR/><B>Connexion au serveur de Base de Données impossible</B><BR/>' ;
		exit();
		
	}

?> 
