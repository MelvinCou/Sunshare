 <?php
	
	//inclusion du fichier connexion bdd
	require 'ConnexionBdD.php';

	// instructions et requêtes sur la base de données
	$Requete = "SELECT date, energie_soutiree, energie_injectee, energie_produite FROM Energies_TempsReel ORDER BY date DESC LIMIT 1;" ;
	//echo $Requete ;
	
	$Resultat = mysqli_query($bConnect,$Requete) ;

	if ($Resultat) {
		
		if (mysqli_num_rows($Resultat) > 0) {
			
				//mysqli_fetch_array renvoie les données dans un tableau associatif avec un nom de colonne comme clé du tableau résultant.
				//Cela veut dire que nous pouvons accéder au tableau de sortie avec un nom de colonne comme clé d'un tableau.
				//Comme par exemple l.23 , l.28 et l.33				
				while($row = mysqli_fetch_assoc($Resultat)) {
																		
						echo"<tr>";
						echo"<th scope=\"row\">Production </th>";
						echo "<td  style=\"text-align : center; font-size:20px;\" >".$row["energie_produite"]." Wh</td>";
						echo"</tr>";
						
						echo"<tr>";
						echo"<th scope=\"row\">Consommation</th>";
						echo "<td style=\"text-align : center;font-size:20px;\">".$row["energie_soutiree"]." Wh</td>";
						echo"</tr>";
						
						echo"<tr>";
						echo"<th scope=\"row\">Injection</th>";	
						echo "<td  style=\"text-align : center; font-size:20px;\" >".$row["energie_injectee"]." Wh</td>";	
						echo"</tr>";											
				}
		}
		
	}
	
	//Fermeture de la connexion
	mysqli_close($bConnect);
			

?>
