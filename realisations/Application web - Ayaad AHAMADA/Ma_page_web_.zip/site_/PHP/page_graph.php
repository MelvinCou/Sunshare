<html>
	<head>

		<!-- librairie bootstrap -->
		<link charset="UTF-8" href="../Bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" /> 
			
		<meta http-equiv="content-type" content="text/html;charset=UTF-8">
		
		<!-- librairie chartjs-->
		<script src="../ChartJS/dist/chart.min.js">  </script>
		
		<!-- librairie pdfjs -->	
		<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.14.305/pdf.min.js" 
				integrity="sha512-dw+7hmxlGiOvY3mCnzrPT5yoUwN/MRjVgYV7HGXqsiXnZeqsw1H9n9lsnnPu4kL2nx2bnrjFcuWK+P3lshekwQ==" 
				crossorigin="anonymous" referrerpolicy="no-referrer">
		</script>
		
		<!-- librairie a ajouté en plus de pdfjs, sinon affichage d'erreur -->	
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.debug.js">  </script>
		
			
			
		<title>SunShare Supervisor | Graph </title>
	</head>
	
    <body>

		    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
				<div class="container-fluid">
					<a class="navbar-brand" href="../PHP/page_accueil.php"><img src="../Images/SnSr_logo.png" alt="SunShare Logo" style="width:40px;" class="rounded-pill">
						SunShare Supervisor
					</a>
					
					<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
						<span class="navbar-toggler-icon"></span>
					</button>
					
				    <div class="collapse navbar-collapse" id="collapsibleNavbar">
						<ul class="navbar-nav">
					 
							<li class="nav-item">
								<a class="nav-link" href="../PHP/page_accueil.php">Accueil</a>
							</li>

							<li class="nav-item">
							   <a class="nav-link" href="../HTML/page_historique.html" >Historique</a>
							</li>
							
						</ul>
				    </div>
				</div>
		    </nav>

		   <div class="container-fluid">
				<div class="container">

					<div class="row ">
					
						   <article class="col-xs-12 col-md-2 col-lg-4"> </article>
						   
						   <div class="container-fluid ">
								<article class="col-md-">
							   </article>
						   </div>
					</div>

				</div>

				</BR>

				<?php			   
				   	//inclusion du fichier contenant les requêtes
					 require 'ReqGraph.php';
				 ?>
			
		<table align="center">
				<tr>
						<th>					
							<form  ACTION="../PHP/page_graph.php" METHOD="POST">
									<div class="container">
									 
										 </br></br>
										 
											<!-- La saisie de date   -->
											<div class="row justify-content-center">
											
														<h5 style="text-align : center"> Définir une période, pour la consultation graphique </h5>
														
														</br></br>

														<div class="col-md-auto">
														
																<table align="center">
																  
																		<tr>																		
																			<td>
																				<div class="mb-5" >
																					<h6> Du </h6>
																				</div>
																			</td>
																			
																			<td>														 
																				<div class="custom-control custom-checkbox mb-3" >

																					<input class="shadow-lg p-2 mb-5 bg-white"  name="DebutDate" placeholder ="aaaa-mm-jj" required>
																					<span class="validity"></span>																	
																				</div>
																				<input type="hidden" >
																			</td>
																			
																			<td>
																				<div class="mb-5" >
																					<h6> au </h6>
																				</div>	
																			</td>
																			
																			<td>																	
																				<div class="custom-control custom-checkbox mb-3">																		
																					  <input class="shadow-lg p-2 mb-5 bg-white" name="FinDate" placeholder ="aaaa-mm-jj"  required>
																					  <span class="validity"></span>																		  
																				</div>
																				<input type="hidden" >
																			</td>
																		</tr>
																			
																</table>
																
														</div>
														
														<div class="col-md-auto">											
															<div class="col-11"> <button type="submit" ; class="btn btn-outline-success mb-5 ">Valider</button> </div>												
														</div>
											</div>
										  											
											<div class="row justify-content-center">
											
													<!-- La selection période   -->									 
													<div class="col-md-auto">
														
															 <div class="col">	
															 
																	<label class="form-label" style = "text-align : center"> Période </label>																	
																	</br>																	
																	<select name="Select" class="form-select" id="" required>
																	
																		  <option selected disabled value="">Choisir...</option>																	
																		  <option value = "journalier"> Evolution : production, injection et consommation journalière </option>
																		  <option value = "hebdomadaire"> Evolution : production, injection et consommation hebdomadaire </option>
																		  <option value = "mensuel"> Evolution : production, injection et consommation mensuelle </option>
																		  <option value = "annuel"> Evolution : production, injection et consommation annuelle </option>
																		  
																	</select>																	
															</div>												  
													</div>										
											</div>
									</div>
									
									</br>						
							</form>							
						</th>												
				</tr>
		</table>

		<?php
				if ($Select == 'journalier'){	
					
						echo "<h5 style =\"text-align : center;\" > Energie journalière du  $DateD  au  $DateF  </h5>";
						
				}else if  ($Select == 'hebdomadaire'){
					
						echo "<h5 style =\"text-align : center;\" > Energie hebdomadaire du $DateD au  $DateF </h5>";
					
				}else if  ($Select == 'mensuel'){
					
						echo "<h5 style =\"text-align : center;\" > Energie mensuelle du $DateD au  $DateF </h5>";
						
				}else if  ($Select == 'annuel'){
					
						echo "<h5 style =\"text-align : center;\" > Energie annuelle du $DateD au  $DateF </h5>";
						
				}
		?>

		</br></br></br>
	 
		<div class="row">
		
				<div class="col-sm-6 col-lg-6">
						<div class="card">
								<div class="card-body">
								
									   <!-- canvas pour le graphique bar -->
									   <div class="col">
									   
												<div class="container col-sm-6 col-lg-6 "  style="width:100%">

													<canvas id="MyChartBar">  </canvas>
																									   
												</div>												
									   </div>
								</div>
						</div>
				</div>
			  
				<div class="col-sm-6">
					<div class="card">
						<div class="card-body">	  

									 <!-- canvas pour le graphique line  -->
									<div class="col">

											<div class="container "  style="width:100%">
											
											   <canvas id="MyChartLine">  </canvas>
											  
											</div>
										
									</div>
						 </div>
					</div>
				</div>
		</div>
			
		</br></br>
		<!-- Bouton pour la version PDF, qui exécute downloadPDF() lorsque le bouton est cliqué  -->	
		<div class="col-md-auto">		
				<div class="col">																 
					<div class="col-12"> <button  class="btn btn-outline-primary mb-5 " ; onclick="downloadPDF()"> Version PDF </button> </div>	 	 		
				</div>				
		</div>													

		</BR>

		<!-- Script pour la création de graphique -->
		<script>	
					
					//1er Bloc setup
					
          			//Conversion des données (energie_produite, energie_soutiree,
                    //energie_produite et date) en format Json pour que les données soit
                    //lisible pour javascript 
					const energie_produite = <?php echo json_encode($energie_produite); ?>;
					const energie_soutiree = <?php echo json_encode($energie_soutiree); ?>;
					const energie_injectee = <?php echo json_encode($energie_injectee); ?>;
					const date = <?php echo json_encode($date); ?>;

					const data ={
						
							labels: date,
							datasets:[
							{
								  label: 'Production ',
								  data: energie_produite,
								  backgroundColor :['rgba(93, 173, 226, 0.9)',],
								  borderColor: ['rgba(93, 173, 226, 0.6)',],
								  borderWidth : 1,
								  pointRadius: 5,
							},{
								  label: 'Consommation',
								  data: energie_soutiree,
								  backgroundColor :['rgba(172, 255, 98, 1)',],
								  borderColor: ['rgba(0, 0, 0, 0.6)',],
								  borderWidth : 1,
								  pointStyle: 'rectRounded',
								  pointRadius: 5,
							},{
								  label: 'Injection',
								  data: energie_injectee,
								  backgroundColor :['rgba(220, 118, 51, 0.9',],
								  borderColor: ['rgba(142, 68, 173, 0.9)',],
								  borderWidth : 1,
								  pointStyle: 'triangle',
								  pointRadius: 5,
							}]
							
					};
												
					//Bloc Config bar
					const config ={
						 
							type: 'bar',
							data,						 
							options:{
								
									responsive: true,
									scales:{
										
											yAxes:{
												
													beginAtZero:true,  
													title:{															
															display: true,
															text: 'Energie (Wh)'	
													}											  	
											}
										  
									},
									
									plugins:{
										
											legend:{										
												position: 'bottom',										 
											},
									}  									                            
							}
					};


					// Bloc de rendu bar
					const MyChartBar = new Chart(
					 document.getElementById('MyChartBar'),
					 config
					);
					
										
					//Bloc Config line 					 
					const ConfigLine = {
						 
							type: 'line',
							data,
							 
							options: {
								
									scales: {
										
											yAxes: {
												
													beginAtZero:true,
													title: {
															display: true,
															text: 'Energie (Wh)'										  
													}
													
											}
										
									},
										  
									plugins:{
																												  
											legend:{
												position: 'bottom',
											},																																									
									},

																			 
							}
					};
						  						  
					// Bloc de rendu  line						
					const MyChartLine = new Chart(
					  document.getElementById('MyChartLine'),
					  ConfigLine
					);
																							
		</script>
		
		<script>

			//generer un pdf
			function downloadPDF(){

				const canvas = document.getElementById('MyChartLine');
				//créer une image
				//toDataURL(type)
				const canvasImage = canvas.toDataURL('image/png');
				console.log(canvasImage);
				
				//mise en format pdf
				let pdf = new jsPDF('landscape');
				pdf.setFontSize(20);
				pdf.text(15, 15, "						Graphique n°2");
				//addImage (imageData, format, x, y, largeur, hauteur)
				pdf.addImage(canvasImage, 'png', 15, 15, 250, 140);
				pdf.save('Graphique.pdf');
			}
			
		</script>
		

		</div>
	</div>


    </body>
</html>
