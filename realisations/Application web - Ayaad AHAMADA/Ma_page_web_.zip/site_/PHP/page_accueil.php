<html>
  <head>

		<!-- librairie bootstrap -->
		<link charset="UTF-8" href="../Bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" /> 
		
		<link charset="UTF-8" href="../CSS/MesStyles.css" rel="stylesheet" type="text/css" />
		
		<link charset="UTF-8" href="../CSS/Vibur.css" rel="stylesheet" type="text/css" />
		
		<meta http-equiv="refresh; content-type" content="10;text/html;charset=UTF-8">

		<title>SunShare Supervisor | Accueil </title>
  </head>
  <body>
  
	<!-- La barre de menue -->
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
		    <div class="container-fluid">
		  
					<a class="navbar-brand" href="../PHP/page_accueil.php"><img src="../Images/SnSr_logo.png" alt="SunShare Logo" style="width:40px;" class="rounded-pill">
						SunShare Supervisor
					</a>
					
					<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
						<span class="navbar-toggler-icon"></span>
					</button>
				
					<div class="collapse navbar-collapse" >
					
					
					    <ul class="navbar-nav">
						
								<li class="nav-item">
								  <a class="nav-link" href="../PHP/page_accueil.php">Accueil</a>
								</li>

								<li class="nav-item">
								  <a class="nav-link" href="../HTML/page_historique.html" >Historique</a>
								</li>

								<li class="nav-item ">         
									<a class="nav-link" href="../PHP/page_graph.php">Graphique</a>
								</li>

								<li class="nav-item ">
									<a class="nav-link" href="https://sunshare.fr/">SunShare</a>
								</li>
								
						</ul >	
					  
					</div>
		    </div>
    </nav>


	<!-- inclusion du fichier Utilisateur.php -->
	<?php
		require 'Utilisateur.php';
	?>
	
	<div class="container-fluid">

	<H3> <B>Bienvenue sur SunShare Supervisor </B> </H3>
	
		
			<tr><td> <?php echo $user_nom; ?> </td> <td> <?php echo $user_Prenom; ?></td></tr>
			</br>
			<tr><td> N°PDL : </td> <td> <?php echo $Num_pdl ; ?> </td></tr>		
							
	</div>						 
	
	<div class="container">

	
			</BR> </BR>


			<div id="" class="mx-auto d-block w-50 h-25 carousel slide" data-bs-ride="carousel">
				<div class="carousel-inner">
				
						<div class="carousel-item active" data-bs-interval="10000">
								<img src="../Images/production.jpg" class="d-block w-100" alt="...">
								</BR> </BR> </BR>
						</div>
						
						<div class="carousel-item" data-bs-interval="2000">
								<img src="../Images/autoconso.png" class="d-block w-100" alt="...">
								</BR> </BR> </BR>
						</div>
						
						<div class="carousel-item">
								<img src="../Images/injection.png" class="d-block w-100" alt="...">
								</BR> </BR></BR> 
						</div>
				</div>
				  
				<button class="carousel-control-prev" type="button" data-bs-target="" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Previous</span>
				</button>
				  
				<button class="carousel-control-next" type="button" data-bs-target="" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Next</span>
				</button>
				  
			</div>

			 </BR></BR> </BR> </BR> </BR> </BR> </BR> </BR> </BR>
			
	</div>

  

	<div class="container-fluid">

		<div class="row">
		  <div class="col-sm-6">
			<div class="card bg-dark text-white">
			  <div class="card-body">
				<h5 class="card-title"> Actuellement </h5>
		   
					<div class="container" >
						</BR>
							<table class="table table-borderedless text-white"  id="table-refresh">		
								<thead>
									<?php   
										include ('../PHP/EnergieInstantanee.php');          
									?>
								</thead>
							</table>
					</div>  
				
			  </div>
			</div>
		  </div>
		  
		    <div class="col-sm-6">
				<div class="card bg-dark text-white">
					<div class="card-body">	  
						<h5 class="card-title">La journée d'hier </h5>	
						
							<div class="container" >
								</BR>
									<table class="table table-borderedless text-white" id="table_refresh">		
										<thead>
											<?php   
												include ('../PHP/EnergieJournaliere.php');          
											?>
										</thead>
									</table>
							</div> 					  
					</div>
			    </div>
		  </div>
		</div>

		</BR></BR>

		<div class="row">
		  <div class="col-sm-6">
			<div class="card bg-dark text-white">
			  <div class="card-body">
				<h5 class="card-title"> Le mois passé </h5>
				
					<div class="container" >
						</BR>
							<table class="table table-borderedless text-white" id="tableM_refresh">		
								<thead>
									<?php   
										include ('../PHP/EnergieMensuelle.php');          
									?>
								</thead>
							</table>
					</div> 
				
			  </div>
			</div>
		  </div>
		  
		  <div class="col-sm-6">
			<div class="card bg-dark text-white">
			  <div class="card-body" >  
				<h5 class="card-title">L'année passé </h5>
			
					<div class="container" >
						</BR>
							<table class="table table-borderedless text-white" id="tableA_refresh" >		
							  
								<thead>
									<?php   
										include ('../PHP/EnergieAnnuelle.php');          
									?>
								</thead>
							</table>
					</div> 
			  
			  </div>
			</div>
		  </div>
		</div>
	
    </div>
</BR></BR>

	<script src="../lib_jQuery/jquery-3.6.0.js"></script>
    <script src="../lib_jQuery/bootstrap.min.js"></script>

	<!-- Script de rafraîchissement en javascript  -->
    <script  type="text/javascript">

		setInterval (function(){
		  $("#table-refresh").load ("page_accueil.php #table-refresh")
		}, 2000);

    </script>

	
	
	

  </body>
</html>
