<?php

	$DateD= $_REQUEST['DebutDate'];
   	$DateF= $_REQUEST['FinDate'];

	//inclusion de fichier
	require '../PHP/ConnexionBdD/connexion.php';
	
	if(empty($DateD) || empty($DateF))
	{
		// instructions et requêtes sur la base de données
		$Requete = "SELECT date, energie_soutiree, energie_injectee, energie_produite FROM Energies_Annuelle WHERE date < CURRENT_DATE ORDER BY date DESC LIMIT 10;" ;
	} else {
		$Requete = "SELECT date, energie_soutiree, energie_injectee,
			energie_produite FROM Energies_Annuelle WHERE date >= 
			\"".$DateD."\" AND date <= \"".$DateF."\" ORDER BY date DESC ;" ;
	}

	//echo $Requete ;
	$Resultat = mysqli_query($bConnect,$Requete) ;

	if (mysqli_num_rows($Resultat) <> 0)
    {
		
		while($row=mysqli_fetch_array($Resultat))
		{  
			  $json[] = $row;                     
			  //echo $row;
		} 
		echo json_encode($json, JSON_UNESCAPED_UNICODE); //Mise en format Json
       
    }
    else{	
		echo "Pas de résultats !" ;
	}
	
	//Fermeture de la connexion
	mysqli_close($bConnect);

?>
