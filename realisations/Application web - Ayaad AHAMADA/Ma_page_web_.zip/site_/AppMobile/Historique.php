<?php

   $DateD= $_REQUEST['DebutDate'];
   $DateF= $_REQUEST['FinDate'];
  
   $ServeurBdD = "127.0.0.1" ;
   $PortBdD = "3306";
   $User = "admin" ;
   $Password = "admin" ;
   $BdD = "SunshareBDD" ;

	// Connexion au serveur de la base de données
	$bConnect = mysqli_connect(
           $ServeurBdD.":".$PortBdD,
           $User,
           $Password,
           $BdD) ;
	if(!$bConnect)
	{
     Echo '<BR/><BR/><B>Connexion au serveur de Base de Données impossible</B><BR/>' ;
     exit() ;
	}
   
    // instructions et requêtes sur la base de données  
	$Requete = "SELECT energie_soutiree, energie_injectee, energie_produite, date FROM Energies_TempsReel WHERE date >= \"".$DateD."\" AND date <= \"".$DateF."\" ORDER BY date DESC ;" ;     
	

	$Resultat = mysqli_query($bConnect, $Requete);
 
	echo mysqli_error($bConnect);
   
	$json = array();


	if (mysqli_num_rows($Resultat) <> 0)
	{		
		while($row=mysqli_fetch_array($Resultat))
		{  
			  $json[] = $row;
			  //echo $row;
		} 
		echo json_encode($json, JSON_UNESCAPED_UNICODE); //Mise en format Json
       
    }
    else{
		
		echo "Pas de résultats !" ;
	}

    mysqli_close($bConnect);
    
?>
