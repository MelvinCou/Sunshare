<?php

	$Select = $_POST['Select'];

	//if ($Select == 'TReel'){	
					
		//require("../CSV/TempsReel.php");
			
	//}else if  ($Select == 'Journaliere'){
		
		//require("./CSV/Journaliere.php");
		
	//}else if  ($Select == 'hebdo'){
		
		//require("CSV/Hebdo.php");
			
	//}else if  ($Select == 'mois'){
		
		//require("CSV/Mensuelle.php");			
			
	//}else if  ($Select == 'annuelle'){
		
		//require("CSV/Annuelle.php");
			
	//}


	if(isset($_POST['Select'])){
	   
	   
		switch ($Select){
			//Choix 1 : journalier (pour consulter l'historique journalier)
			case 'TReel':				
				require "../CSV/TempsReel.php";
				break;
			//Choix 2 : hebdomadaire (pour consulter l'historique hebdomadaire)	
			case 'Journaliere':
			   require("../CSV/TempsReel.php");
				break;
			//Choix 3 : mensuel (pour consulter l'historique mensuel)	
			case 'hebdo':
				 include("../CSV/TempsReel.php");			
				break;
			//Choix 4 : annuel (pour consulter l'historique annuel)	
			case 'mois':
			   
			   require("CSV/Mensuelle.php");
				//echo  $Requete;
				break;
				
			case 'annuelle':
				require("CSV/Annuelle.php");			
				break;
			
			default:
				break;
				
		}
	}



?>