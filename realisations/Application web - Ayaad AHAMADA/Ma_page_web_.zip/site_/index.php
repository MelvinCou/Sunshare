<?php
    
	
	include ('./PHP/page_accueil.php') ;

?>